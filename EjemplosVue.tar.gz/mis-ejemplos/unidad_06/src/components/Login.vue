<template>
  <div class="login">
    <form id="login" @submit="checkForm" action="/login" method="post">
      <p>
          <label for="name">Name</label>
          <input type="text" name="name" id="name" v-model="userName">
      </p>

      <p>
          <label for="pass">Pass</label>
          <input type="text" name="age" id="pass" v-model="pass">
      </p>
      
      <p>
        <input type="submit" value="Submit">
      </p>
    </form>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
        userName: '',
        pass: ''
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
