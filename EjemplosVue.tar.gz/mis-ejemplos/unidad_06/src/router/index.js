import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import ListadoClientes from '@/components/ListadoClientes'
import Login from '@/components/Login'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/listadoClientes',
      name: 'ListadoClientes',
      component: ListadoClientes
    },
    {
      path: '/login',
      name: 'Login',
      component: Login
    }
  ]
})
